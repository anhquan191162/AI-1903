f = open("f1.txt", "r")
print(f.read())